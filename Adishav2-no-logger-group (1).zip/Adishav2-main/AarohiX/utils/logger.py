"""Playback logging is disabled because this bot no longer uses a global logger group."""


async def play_logs(message, streamtype):
    # Kept as a no-op for compatibility with existing playback handlers.
    return None
